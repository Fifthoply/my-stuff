import torch
import diffusers
from sdnq import SDNQConfig
from sdnq.loader import apply_sdnq_options_to_model
from flask import Flask, render_template, request, jsonify, send_file
import threading
import queue
import uuid
import io
import base64
from datetime import datetime
from collections import OrderedDict
import time

app = Flask(__name__)

# ============================================================================
# Global State
# ============================================================================
pipe = None
generation_queue = queue.Queue()
results_lock = threading.Lock()
queue_lock = threading.Lock()
is_generating = False
current_task_id = None

# Batch results with tracking of sent images
batch_results = OrderedDict()

# Image storage (batch_id -> {index -> image_bytes})
image_storage = OrderedDict()

# Generation history (metadata only, no image data)
generation_history = []

MAX_STORED_BATCHES = 50
MAX_HISTORY = 50
MAX_QUEUE_SIZE = 50


# ============================================================================
# Pipeline Initialization
# ============================================================================
def initialize_pipeline():
    """Initialize the Z-Image-Turbo pipeline (called once at startup)"""
    global pipe
    
    print("=" * 60)
    print("Initializing Z-Image-Turbo SDNQ Pipeline...")
    print("=" * 60)
    
    pipe = diffusers.ZImagePipeline.from_pretrained(
        "Disty0/Z-Image-Turbo-SDNQ-uint4-svd-r32",
        torch_dtype=torch.float32,
        device_map="cuda"
    )
    
    pipe.transformer = apply_sdnq_options_to_model(
        pipe.transformer, 
        use_quantized_matmul=True
    )
    pipe.text_encoder = apply_sdnq_options_to_model(
        pipe.text_encoder, 
        use_quantized_matmul=True
    )
    
    print("Pipeline initialized successfully!")
    print("=" * 60)


# ============================================================================
# Image Storage Management
# ============================================================================
def store_image(batch_id, index, image_bytes, generation_time):
    """Store image bytes and metadata"""
    if batch_id not in image_storage:
        image_storage[batch_id] = {}
    
    image_storage[batch_id][index] = {
        'bytes': image_bytes,
        'generation_time': generation_time
    }
    
    # Cleanup old batches
    while len(image_storage) > MAX_STORED_BATCHES:
        oldest_key = next(iter(image_storage))
        del image_storage[oldest_key]


def get_image_bytes(batch_id, index):
    """Get raw image bytes for download/display"""
    if batch_id in image_storage and index in image_storage[batch_id]:
        return image_storage[batch_id][index]['bytes']
    return None


def get_image_base64(batch_id, index):
    """Get image as base64 string"""
    image_bytes = get_image_bytes(batch_id, index)
    if image_bytes:
        return base64.b64encode(image_bytes).decode('utf-8')
    return None


# ============================================================================
# Queue Processor
# ============================================================================
def process_queue():
    """Background thread that processes the generation queue"""
    global is_generating, current_task_id
    
    while True:
        try:
            task = generation_queue.get()
            
            with queue_lock:
                is_generating = True
                current_task_id = task['batch_id']
            
            batch_id = task['batch_id']
            
            # Update batch status to processing
            with results_lock:
                if batch_id in batch_results:
                    batch_results[batch_id]['status'] = 'processing'
                    batch_results[batch_id]['started_at'] = datetime.now().isoformat()
            
            try:
                batch_start_time = time.time()
                
                for idx in range(task['num_images']):
                    # Update current image being generated
                    with results_lock:
                        if batch_id in batch_results:
                            batch_results[batch_id]['current_image'] = idx + 1
                    
                    start_time = time.time()
                    
                    # Generate the image
                    image = pipe(
                        prompt=task['prompt'],
                        height=task['height'],
                        width=task['width'],
                        num_inference_steps=9,
                        guidance_scale=0.0,
                    ).images[0]
                    
                    generation_time = time.time() - start_time
                    
                    # Convert to bytes and store
                    buffered = io.BytesIO()
                    image.save(buffered, format="PNG")
                    image_bytes = buffered.getvalue()
                    
                    # Store image in storage
                    store_image(batch_id, idx, image_bytes, round(generation_time, 2))
                    
                    # Mark image as ready (but not yet sent) in batch results
                    with results_lock:
                        if batch_id in batch_results:
                            batch_results[batch_id]['ready_images'].append({
                                'index': idx,
                                'generation_time': round(generation_time, 2),
                                'sent': False  # Not yet sent to client
                            })
                    
                    print(f"Batch {batch_id[:8]}... Image {idx + 1}/{task['num_images']} ready ({generation_time:.2f}s)")
                
                total_time = time.time() - batch_start_time
                
                # Mark batch as completed
                with results_lock:
                    if batch_id in batch_results:
                        batch_results[batch_id]['status'] = 'completed'
                        batch_results[batch_id]['total_time'] = round(total_time, 2)
                        batch_results[batch_id]['completed_at'] = datetime.now().isoformat()
                    
                    # Add to history (metadata only)
                    history_entry = {
                        'id': batch_id,
                        'prompt': task['prompt'],
                        'width': task['width'],
                        'height': task['height'],
                        'num_images': task['num_images'],
                        'total_time': round(total_time, 2),
                        'completed_at': datetime.now().isoformat()
                    }
                    generation_history.insert(0, history_entry)
                    
                    while len(generation_history) > MAX_HISTORY:
                        generation_history.pop()
                
                print(f"Batch {batch_id[:8]}... completed! Total: {total_time:.2f}s")
                
            except Exception as e:
                print(f"Error generating batch {batch_id}: {e}")
                with results_lock:
                    if batch_id in batch_results:
                        batch_results[batch_id]['status'] = 'error'
                        batch_results[batch_id]['error'] = str(e)
            
            with queue_lock:
                is_generating = False
                current_task_id = None
            
            generation_queue.task_done()
            
        except Exception as e:
            print(f"Critical error in queue processor: {e}")
            with queue_lock:
                is_generating = False
                current_task_id = None


# ============================================================================
# Flask Routes
# ============================================================================
@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    """Submit a new batch generation request"""
    
    if generation_queue.qsize() >= MAX_QUEUE_SIZE:
        return jsonify({
            'error': 'Queue is full. Please try again later.',
            'queue_size': generation_queue.qsize()
        }), 429
    
    data = request.json or {}
    
    prompt = data.get('prompt', '').strip()
    if not prompt:
        return jsonify({'error': 'Prompt is required'}), 400
    
    num_images = int(data.get('num_images', 4))
    height = int(data.get('height', 1024))
    width = int(data.get('width', 1024))
    
    # Validate ranges
    num_images = max(1, min(num_images, 8))
    height = max(512, min(height, 2048))
    width = max(512, min(width, 2048))
    height = (height // 64) * 64
    width = (width // 64) * 64
    
    batch_id = str(uuid.uuid4())
    task = {
        'batch_id': batch_id,
        'prompt': prompt,
        'num_images': num_images,
        'height': height,
        'width': width,
        'created_at': datetime.now().isoformat()
    }
    
    # Initialize batch result
    with results_lock:
        batch_results[batch_id] = {
            'status': 'queued',
            'prompt': prompt,
            'num_images': num_images,
            'height': height,
            'width': width,
            'ready_images': [],  # Images that are ready
            'current_image': 0,
            'created_at': task['created_at']
        }
        
        # Cleanup old batch results
        while len(batch_results) > MAX_STORED_BATCHES:
            oldest_key = next(iter(batch_results))
            del batch_results[oldest_key]
    
    generation_queue.put(task)
    
    print(f"New batch queued: {batch_id[:8]}... | {num_images} images | Prompt: {prompt[:50]}...")
    
    return jsonify({
        'batch_id': batch_id,
        'status': 'queued',
        'queue_position': generation_queue.qsize()
    })


@app.route('/batch/<batch_id>')
def get_batch_status(batch_id):
    """
    Get batch status. 
    NEW images are sent with base64 data ONLY ONCE.
    Already-sent images are listed without data.
    """
    with results_lock:
        if batch_id not in batch_results:
            return jsonify({'status': 'not_found', 'error': 'Batch not found'}), 404
        
        batch = batch_results[batch_id]
        
        # Prepare response
        response = {
            'status': batch['status'],
            'prompt': batch['prompt'],
            'num_images': batch['num_images'],
            'height': batch['height'],
            'width': batch['width'],
            'current_image': batch.get('current_image', 0),
            'new_images': [],      # Images being sent for the first time (with data)
            'sent_images': [],     # Images already sent previously (no data)
        }
        
        if batch.get('total_time'):
            response['total_time'] = batch['total_time']
        
        if batch.get('error'):
            response['error'] = batch['error']
        
        # Process ready images
        for img_info in batch.get('ready_images', []):
            if not img_info['sent']:
                # First time sending this image - include base64 data
                img_base64 = get_image_base64(batch_id, img_info['index'])
                if img_base64:
                    response['new_images'].append({
                        'index': img_info['index'],
                        'image': img_base64,
                        'generation_time': img_info['generation_time']
                    })
                    # Mark as sent
                    img_info['sent'] = True
            else:
                # Already sent - just include metadata
                response['sent_images'].append({
                    'index': img_info['index'],
                    'generation_time': img_info['generation_time']
                })
        
        return jsonify(response)


@app.route('/image/<batch_id>/<int:index>')
def get_image(batch_id, index):
    """Serve an image (for history thumbnails)"""
    image_bytes = get_image_bytes(batch_id, index)
    if image_bytes:
        return send_file(
            io.BytesIO(image_bytes),
            mimetype='image/png'
        )
    return "Image not found", 404


@app.route('/download/<batch_id>/<int:index>')
def download_image(batch_id, index):
    """Download a specific image"""
    image_bytes = get_image_bytes(batch_id, index)
    if image_bytes:
        return send_file(
            io.BytesIO(image_bytes),
            mimetype='image/png',
            as_attachment=True,
            download_name=f'zit-{batch_id[:8]}-{index}.png'
        )
    return "Image not found", 404


@app.route('/history')
def get_history():
    """Get generation history (metadata only, images fetched via /image/)"""
    with results_lock:
        return jsonify(generation_history[:20])


@app.route('/queue')
def queue_info():
    """Get current queue information"""
    with queue_lock:
        return jsonify({
            'queue_size': generation_queue.qsize(),
            'is_generating': is_generating,
            'current_batch_id': current_task_id
        })


@app.route('/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'pipeline_loaded': pipe is not None,
        'queue_size': generation_queue.qsize(),
        'is_generating': is_generating
    })


# ============================================================================
# Main Entry Point
# ============================================================================
if __name__ == '__main__':
    initialize_pipeline()
    
    processor_thread = threading.Thread(target=process_queue, daemon=True)
    processor_thread.start()
    print("Queue processor started!")
    
    print("\nStarting Flask server...")
    print("Access the webapp at: http://localhost:5000")
    print("=" * 60)
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        threaded=True
    )