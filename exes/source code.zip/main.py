import webview
import os
import sys

def get_resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, relative_path)

ruta_html = get_resource_path('web/index.html')

# Create a rigid, borderless window
window = webview.create_window(
    'mexican cockroach',    # Title won't be visible
    url=ruta_html,
    frameless=True,    # Removes title bar, close, minimize, maximize buttons
    resizable=False,   # Prevents resizing
    easy_drag=False,   # Prevents dragging the window around
    width=834,         
    height=720
)

webview.start()